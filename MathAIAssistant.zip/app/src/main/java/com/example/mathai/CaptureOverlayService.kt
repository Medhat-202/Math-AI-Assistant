package com.example.mathai

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: LinearLayout? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private lateinit var output: TextView
    private var busy = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("projectionData") ?: return START_NOT_STICKY
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        showOverlay()
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "math_ai_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Math AI screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("Math AI Assistant")
                .setContentText("مشاركة الشاشة نشطة بإذنك").setSmallIcon(android.R.drawable.ic_menu_view).build()
        else Notification.Builder(this).setContentTitle("Math AI Assistant")
            .setContentText("مشاركة الشاشة نشطة بإذنك").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(10, notification)
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        output = TextView(this).apply {
            text = "جاهز لقراءة المسألة"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 10, 14, 10)
        }
        val read = Button(this).apply { text = "اقرأ الآن"; setOnClickListener { captureAndRead() } }
        val close = Button(this).apply { text = "×"; setOnClickListener { stopSelf() } }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xEE292044.toInt())
            addView(close)
            addView(output)
            addView(read)
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        wm.addView(overlay, params)
    }

    private fun captureAndRead() {
        if (busy) return
        busy = true
        output.text = "بقرأ الشاشة..."
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader?.close()
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay?.release()
        virtualDisplay = projection?.createVirtualDisplay(
            "MathAI", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage()
            if (image != null) {
                val bitmap = image.toBitmapCompat()
                image.close()
                virtualDisplay?.release()
                virtualDisplay = null
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        val answer = MathSolver.solve(result.text)
                        output.text = when {
                            answer == null -> "مش قادر أقرأ المسألة بوضوح"
                            answer.truth == null -> "${answer.expression}\nالناتج: ${answer.result}"
                            answer.truth -> "${answer.expression}\n✓ العبارة صحيحة"
                            else -> "${answer.expression}\n✕ العبارة خاطئة"
                        }
                    }
                    .addOnFailureListener { output.text = "تعذر تحليل الصورة" }
                    .addOnCompleteListener { recognizer.close(); busy = false }
            }
        }, null)
    }

    private fun android.media.Image.toBitmapCompat(): android.graphics.Bitmap {
        val plane = planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val bitmap = android.graphics.Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, android.graphics.Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(buffer)
        return android.graphics.Bitmap.createBitmap(bitmap, 0, 0, width, height)
    }

    override fun onDestroy() {
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
