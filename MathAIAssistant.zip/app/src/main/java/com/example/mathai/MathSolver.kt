package com.example.mathai

object MathSolver {
    data class Answer(val expression: String, val truth: Boolean?, val result: String)

    fun solve(raw: String): Answer? {
        var s = raw.lowercase()
            .replace("×", "*").replace("x", "*").replace("÷", "/")
            .replace("−", "-").replace("—", "-")
            .replace(" ", "").replace(",", ".")
            .replace("＝", "=").replace("＞", ">").replace("＜", "<")
        val match = Regex("""[-+*/().0-9]+(?:[<>=][-+*/().0-9]+)?""").find(s) ?: return null
        val expr = match.value
        val opMatch = Regex("""(<=|>=|<|>|=)""").find(expr)
        return try {
            if (opMatch == null) {
                val value = Parser(expr).parse()
                Answer(expr, null, format(value))
            } else {
                val op = opMatch.value
                val left = Parser(expr.substring(0, opMatch.range.first)).parse()
                val right = Parser(expr.substring(opMatch.range.last + 1)).parse()
                val truth = when (op) {
                    "<" -> left < right
                    ">" -> left > right
                    "=" -> kotlin.math.abs(left - right) < 1e-9
                    "<=" -> left <= right
                    ">=" -> left >= right
                    else -> false
                }
                Answer(expr, truth, "${format(left)} $op ${format(right)}")
            }
        } catch (_: Exception) { null }
    }

    private fun format(v: Double): String =
        if (v.isFinite() && kotlin.math.abs(v - v.toLong()) < 1e-9) v.toLong().toString()
        else "%.4f".format(java.util.Locale.US, v)

    private class Parser(private val input: String) {
        private var pos = 0
        fun parse(): Double {
            val value = expression()
            if (pos != input.length) error("Unexpected character")
            return value
        }
        private fun expression(): Double {
            var v = term()
            while (pos < input.length && (input[pos] == '+' || input[pos] == '-')) {
                val op = input[pos++]
                val n = term()
                v = if (op == '+') v + n else v - n
            }
            return v
        }
        private fun term(): Double {
            var v = factor()
            while (pos < input.length && (input[pos] == '*' || input[pos] == '/')) {
                val op = input[pos++]
                val n = factor()
                if (op == '/' && n == 0.0) error("Division by zero")
                v = if (op == '*') v * n else v / n
            }
            return v
        }
        private fun factor(): Double {
            if (pos < input.length && (input[pos] == '+' || input[pos] == '-')) {
                val op = input[pos++]
                val n = factor()
                return if (op == '-') -n else n
            }
            if (pos < input.length && input[pos] == '(') {
                pos++
                val v = expression()
                if (pos >= input.length || input[pos++] != ')') error("Missing )")
                return v
            }
            val start = pos
            while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
            if (start == pos) error("Number expected")
            return input.substring(start, pos).toDouble()
        }
    }
}
